const FormTypes = {
  CREATE: 0,
  MODIFY: 1,
  EDIT: 2,
  LIST: 3,
};

export { FormTypes };
